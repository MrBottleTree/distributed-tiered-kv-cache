"""
KV-Cache gRPC server  —  longest-prefix-match store
=====================================================
Fetch returns the longest stored prefix that is a genuine
prefix of the query sequence, not just an exact hash match.

Internal store key
──────────────────
    (model_id, num_tokens, prefix_hash)

    • model_id    — one namespace per model
    • num_tokens  — lets us iterate candidates in length order
    • prefix_hash — collision-resistant identity (sha256)

Prefix validation
──────────────────
A length-only check is unsafe if two unrelated sequences happen to
have the same token count.  We validate with prefix_chain hashes:

    On Store the client sends prefix_chain = [
        hash(tokens[:64]),
        hash(tokens[:128]),
        ...
        hash(tokens[:num_tokens]),   ← same as prefix_hash
    ]

    On Fetch the server checks: "is stored_entry.prefix_hash
    present in the query's prefix_chain?"  If yes, the stored
    entry is a genuine prefix of the query.  If the chain is
    missing we fall back to length-only (sha256 collision risk
    is negligible).

Run on Machine B:
    python kv_cache_server.py
"""

import sys
import os
from concurrent import futures

import grpc

sys.path.append(os.path.join(os.path.dirname(__file__), "py_client"))
import kv_cache_pb2
import kv_cache_pb2_grpc

LISTEN_ADDR = "[::]:8080"


class KVCacheServicer(kv_cache_pb2_grpc.KVCacheServiceServicer):

    def __init__(self):
        # (model_id, num_tokens, prefix_hash) → KVCacheValue
        self._store: dict[tuple[str, int, str], kv_cache_pb2.KVCacheValue] = {}

        # (model_id, num_tokens, prefix_hash) → set[str]
        # The prefix_chain for this entry: hashes of every sub-prefix
        # at block boundaries.  Used to validate Fetch candidates.
        self._chains: dict[tuple[str, int, str], set[str]] = {}

    # ── helpers ─────────────────────────────────────────────────────────────

    @staticmethod
    def _skey(key: kv_cache_pb2.KVCacheKey) -> tuple[str, int, str]:
        return (key.model_id, key.num_tokens, key.prefix_hash)

    def _is_genuine_prefix(
        self,
        candidate_skey: tuple[str, int, str],
        query_chain: set[str],
    ) -> bool:
        """
        Return True iff the stored entry is a genuine prefix of the query.

        We check whether the candidate's own hash appears in the query's
        prefix_chain (i.e. the query was computed from a token sequence that
        passes through the candidate's token prefix).

        If the caller sent an empty query_chain we have no information and
        accept on length alone (safe with sha256).
        """
        if not query_chain:
            return True   # fallback: no chain info available
        _, _, candidate_hash = candidate_skey
        return candidate_hash in query_chain

    def _find_best(
        self,
        model_id: str,
        query_len: int,
        query_chain: set[str],
    ) -> tuple[int, kv_cache_pb2.KVCacheValue] | None:
        """
        Scan the store and return (matched_tokens, value) for the longest
        entry that:
          1. belongs to model_id
          2. has num_tokens <= query_len
          3. is a genuine prefix of the query (validated via prefix_chain)
        Returns None on miss.
        """
        best: tuple[int, kv_cache_pb2.KVCacheValue] | None = None

        for (m, e_len, _) as skey, value in self._store.items():
            if m != model_id:
                continue
            if e_len > query_len:
                continue
            if not self._is_genuine_prefix(skey, query_chain):
                continue
            if best is None or e_len > best[0]:
                best = (e_len, value)

        return best

    # ── Store ────────────────────────────────────────────────────────────────

    def Store(self, request: kv_cache_pb2.StoreRequest, context):
        skey = self._skey(request.key)
        self._store[skey] = request.value

        # Build chain set: sub-prefix hashes sent by client + own hash
        chain: set[str] = set(request.key.prefix_chain)
        chain.add(request.key.prefix_hash)
        self._chains[skey] = chain

        print(
            f"[STORE] {request.key.model_id[:25]}  "
            f"hash={request.key.prefix_hash[:10]}…  "
            f"tokens={request.value.num_tokens}  "
            f"layers={len(request.value.layers)}  "
            f"chain_entries={len(chain)}"
        )
        return kv_cache_pb2.StoreResponse(success=True, message="OK")

    # ── Fetch ────────────────────────────────────────────────────────────────

    def Fetch(self, request: kv_cache_pb2.FetchRequest, context):
        model_id   = request.key.model_id
        query_len  = request.key.num_tokens
        query_hash = request.key.prefix_hash

        # Build the query's chain so we can validate candidates.
        # The query's own hash is always included; extra hashes may be
        # sent by the client if it already knows its sub-prefix hashes.
        query_chain: set[str] = set(request.key.prefix_chain)
        query_chain.add(query_hash)

        result = self._find_best(model_id, query_len, query_chain)

        if result is None:
            print(
                f"[FETCH] MISS  {model_id[:25]}  "
                f"hash={query_hash[:10]}…  query_len={query_len}"
            )
            return kv_cache_pb2.FetchResponse(found=False, matched_tokens=0)

        matched_len, best_value = result
        reuse_pct = matched_len / query_len * 100 if query_len else 0
        print(
            f"[FETCH] HIT   {model_id[:25]}  "
            f"hash={query_hash[:10]}…  "
            f"query={query_len}  matched={matched_len}  "
            f"reuse={reuse_pct:.1f}%"
        )
        return kv_cache_pb2.FetchResponse(
            found=True,
            value=best_value,
            matched_tokens=matched_len,
        )

    # ── Delete ───────────────────────────────────────────────────────────────

    def Delete(self, request: kv_cache_pb2.DeleteRequest, context):
        skey    = self._skey(request.key)
        removed = self._store.pop(skey, None)
        self._chains.pop(skey, None)
        status  = "OK" if removed else "NOT_FOUND"
        print(f"[DELETE] {status}  hash={request.key.prefix_hash[:10]}…")
        return kv_cache_pb2.DeleteResponse(
            success=removed is not None, message=status
        )


# ─────────────────────────────────────────────────────────────────────────────

def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=4))
    kv_cache_pb2_grpc.add_KVCacheServiceServicer_to_server(
        KVCacheServicer(), server
    )
    server.add_insecure_port(LISTEN_ADDR)
    server.start()
    print(f"KV-Cache server listening on {LISTEN_ADDR}")
    server.wait_for_termination()


if __name__ == "__main__":
    serve()
